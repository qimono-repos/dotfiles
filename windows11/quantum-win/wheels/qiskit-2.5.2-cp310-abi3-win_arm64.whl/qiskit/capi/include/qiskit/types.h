// This code is part of Qiskit.
//
// (C) Copyright IBM 2026
//
// This code is licensed under the Apache License, Version 2.0. You may
// obtain a copy of this license in the LICENSE.txt file in the root directory
// of this source tree or at https://www.apache.org/licenses/LICENSE-2.0.
//
// Any modifications or derivative works of this code must retain this
// copyright notice, and modified files need to carry a notice indicating
// that they have been altered from the originals.


/* Generated with cbindgen:0.29.4 */

#include <stdarg.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include "qiskit\attributes.h"

/**
 * Integer exit codes returned to C.
 */
enum QkExitCode
#if defined(__cplusplus) || __STDC_VERSION__ >= 202311L
  : uint32_t
#endif // defined(__cplusplus) || __STDC_VERSION__ >= 202311L
 {
  /**
   * Success.
   */
  QkExitCode_Success = 0,
  /**
   * Error related to data input.
   */
  QkExitCode_CInputError = 100,
  /**
   * Unexpected null pointer.
   */
  QkExitCode_NullPointerError = 101,
  /**
   * Pointer is not aligned to expected data.
   */
  QkExitCode_AlignmentError = 102,
  /**
   * Index out of bounds.
   */
  QkExitCode_IndexError = 103,
  /**
   * Duplicate index.
   */
  QkExitCode_DuplicateIndexError = 104,
  /**
   * Invalid ``QkOperationKind``.
   */
  QkExitCode_InvalidOperationKind = 105,
  /**
   * Error related to arithmetic operations or similar.
   */
  QkExitCode_ArithmeticError = 200,
  /**
   * Mismatching number of qubits.
   */
  QkExitCode_MismatchedQubits = 201,
  /**
   * Matrix is not unitary.
   */
  QkExitCode_ExpectedUnitary = 202,
  /**
   * Target related error
   */
  QkExitCode_TargetError = 300,
  /**
   * Instruction already exists in the Target
   */
  QkExitCode_TargetInstAlreadyExists = 301,
  /**
   * Properties with incorrect qargs was added
   */
  QkExitCode_TargetQargMismatch = 302,
  /**
   * Trying to query into the target with non-existent qargs.
   */
  QkExitCode_TargetInvalidQargsKey = 303,
  /**
   * Querying an operation that doesn't exist in the Target.
   */
  QkExitCode_TargetInvalidInstKey = 304,
  /**
   * Transpilation failed
   */
  QkExitCode_TranspilerError = 400,
  /**
   * QkDag operation error
   */
  QkExitCode_DagError = 500,
  /**
   * The DAGs have mismatching qubit/clbit amounts during compose.
   */
  QkExitCode_DagComposeMismatch = 501,
  /**
   * One or more bit indices were not found during compose.
   */
  QkExitCode_DagComposeMissingBit = 502,
  /**
   * Errors concerning parameter handling.
   */
  QkExitCode_ParameterError = 600,
  /**
   * Parameter name conflict.
   */
  QkExitCode_ParameterNameConflict = 601,
};
#ifndef __cplusplus
#if __STDC_VERSION__ >= 202311L
typedef enum QkExitCode QkExitCode;
#else
typedef uint32_t QkExitCode;
#endif // __STDC_VERSION__ >= 202311L
#endif // __cplusplus

enum QkGate
#if defined(__cplusplus) || __STDC_VERSION__ >= 202311L
  : uint8_t
#endif // defined(__cplusplus) || __STDC_VERSION__ >= 202311L
 {
  QkGate_GlobalPhase = 0,
  QkGate_H = 1,
  QkGate_I = 2,
  QkGate_X = 3,
  QkGate_Y = 4,
  QkGate_Z = 5,
  QkGate_Phase = 6,
  QkGate_R = 7,
  QkGate_RX = 8,
  QkGate_RY = 9,
  QkGate_RZ = 10,
  QkGate_S = 11,
  QkGate_Sdg = 12,
  QkGate_SX = 13,
  QkGate_SXdg = 14,
  QkGate_T = 15,
  QkGate_Tdg = 16,
  QkGate_U = 17,
  QkGate_U1 = 18,
  QkGate_U2 = 19,
  QkGate_U3 = 20,
  QkGate_CH = 21,
  QkGate_CX = 22,
  QkGate_CY = 23,
  QkGate_CZ = 24,
  QkGate_DCX = 25,
  QkGate_ECR = 26,
  QkGate_Swap = 27,
  QkGate_ISwap = 28,
  QkGate_CPhase = 29,
  QkGate_CRX = 30,
  QkGate_CRY = 31,
  QkGate_CRZ = 32,
  QkGate_CS = 33,
  QkGate_CSdg = 34,
  QkGate_CSX = 35,
  QkGate_CU = 36,
  QkGate_CU1 = 37,
  QkGate_CU3 = 38,
  QkGate_RXX = 39,
  QkGate_RYY = 40,
  QkGate_RZZ = 41,
  QkGate_RZX = 42,
  QkGate_XXMinusYY = 43,
  QkGate_XXPlusYY = 44,
  QkGate_CCX = 45,
  QkGate_CCZ = 46,
  QkGate_CSwap = 47,
  QkGate_RCCX = 48,
  QkGate_C3X = 49,
  QkGate_C3SX = 50,
  QkGate_RC3X = 51,
};
#ifndef __cplusplus
#if __STDC_VERSION__ >= 202311L
typedef enum QkGate QkGate;
#else
typedef uint8_t QkGate;
#endif // __STDC_VERSION__ >= 202311L
#endif // __cplusplus

/**
 * The operation's kind.
 *
 * This is returned when querying a particular node in the graph with ``qk_dag_op_node_kind``,
 * and is intended to allow the caller to dispatch (e.g. via a "switch") calls specific to
 * the contained operation's kind.
 */
enum QkOperationKind
#if defined(__cplusplus) || __STDC_VERSION__ >= 202311L
  : uint8_t
#endif // defined(__cplusplus) || __STDC_VERSION__ >= 202311L
 {
  QkOperationKind_Gate = 0,
  QkOperationKind_Barrier = 1,
  QkOperationKind_Delay = 2,
  QkOperationKind_Measure = 3,
  QkOperationKind_Reset = 4,
  QkOperationKind_Unitary = 5,
  QkOperationKind_PauliProductMeasurement = 6,
  QkOperationKind_ControlFlow = 7,
  /**
   * This variant is used as an opaque type for operations not yet
   * implemented in the native data model.
   */
  QkOperationKind_Unknown = 8,
  QkOperationKind_PauliProductRotation = 9,
};
#ifndef __cplusplus
#if __STDC_VERSION__ >= 202311L
typedef enum QkOperationKind QkOperationKind;
#else
typedef uint8_t QkOperationKind;
#endif // __STDC_VERSION__ >= 202311L
#endif // __cplusplus

/**
 * @ingroup QkCircuit
 *
 * Units for circuit delays.
 */
enum QkDelayUnit
#if defined(__cplusplus) || __STDC_VERSION__ >= 202311L
  : uint8_t
#endif // defined(__cplusplus) || __STDC_VERSION__ >= 202311L
 {
  /**
   * Seconds.
   */
  QkDelayUnit_S = 0,
  /**
   * Milliseconds.
   */
  QkDelayUnit_MS = 1,
  /**
   * Microseconds.
   */
  QkDelayUnit_US = 2,
  /**
   * Nanoseconds.
   */
  QkDelayUnit_NS = 3,
  /**
   * Picoseconds.
   */
  QkDelayUnit_PS = 4,
};
#ifndef __cplusplus
#if __STDC_VERSION__ >= 202311L
typedef enum QkDelayUnit QkDelayUnit;
#else
typedef uint8_t QkDelayUnit;
#endif // __STDC_VERSION__ >= 202311L
#endif // __cplusplus

/**
 * @ingroup QkCircuit
 *
 * The mode to copy the classical variables, for operations that create a new
 * circuit based on an existing one.
 */
enum QkVarsMode
#if defined(__cplusplus) || __STDC_VERSION__ >= 202311L
  : uint8_t
#endif // defined(__cplusplus) || __STDC_VERSION__ >= 202311L
 {
  /**
   * Each variable has the same type it had in the input.
   */
  QkVarsMode_Alike = 0,
  /**
   * Each variable becomes a "capture".
   */
  QkVarsMode_Captures = 1,
  /**
   * Do not copy the variable data.
   */
  QkVarsMode_Drop = 2,
};
#ifndef __cplusplus
#if __STDC_VERSION__ >= 202311L
typedef enum QkVarsMode QkVarsMode;
#else
typedef uint8_t QkVarsMode;
#endif // __STDC_VERSION__ >= 202311L
#endif // __cplusplus

/**
 * @ingroup QkCircuit
 *
 * The mode to use to copy blocks in control-flow instructions, for operations that
 * create a new circuit based on an existing one.
 */
enum QkBlocksMode
#if defined(__cplusplus) || __STDC_VERSION__ >= 202311L
  : uint8_t
#endif // defined(__cplusplus) || __STDC_VERSION__ >= 202311L
 {
  /**
   * Drop the blocks.
   */
  QkBlocksMode_Drop = 0,
  /**
   * Keep the blocks.
   */
  QkBlocksMode_Keep = 1,
};
#ifndef __cplusplus
#if __STDC_VERSION__ >= 202311L
typedef enum QkBlocksMode QkBlocksMode;
#else
typedef uint8_t QkBlocksMode;
#endif // __STDC_VERSION__ >= 202311L
#endif // __cplusplus

/**
 * The different types of expression nodes that can appear in a classical expression tree.
 */
enum QkExprNodeKind
#if defined(__cplusplus) || __STDC_VERSION__ >= 202311L
  : uint8_t
#endif // defined(__cplusplus) || __STDC_VERSION__ >= 202311L
 {
  /**
   * Unary operation expression (e.g., NOT, negation)
   */
  QkExprNodeKind_Unary = 0,
  /**
   * Binary operation expression (e.g., AND, OR, arithmetic operations)
   */
  QkExprNodeKind_Binary = 1,
  /**
   * Type cast expression
   */
  QkExprNodeKind_Cast = 2,
  /**
   * Literal value expression
   */
  QkExprNodeKind_Value = 3,
  /**
   * Variable reference expression
   */
  QkExprNodeKind_Var = 4,
  /**
   * Stretch expression (timing-related)
   */
  QkExprNodeKind_Stretch = 5,
  /**
   * Index/subscript expression
   */
  QkExprNodeKind_Index = 6,
};
#ifndef __cplusplus
#if __STDC_VERSION__ >= 202311L
typedef enum QkExprNodeKind QkExprNodeKind;
#else
typedef uint8_t QkExprNodeKind;
#endif // __STDC_VERSION__ >= 202311L
#endif // __cplusplus

/**
 * The operation types a binary expression can hold.
 * Values are one-based to match Python convention.
 */
enum QkBinaryOpType
#if defined(__cplusplus) || __STDC_VERSION__ >= 202311L
  : uint8_t
#endif // defined(__cplusplus) || __STDC_VERSION__ >= 202311L
 {
  /**
   * Bitwise AND operation
   */
  QkBinaryOpType_BitAnd = 1,
  /**
   * Bitwise OR operation
   */
  QkBinaryOpType_BitOr = 2,
  /**
   * Bitwise XOR operation
   */
  QkBinaryOpType_BitXor = 3,
  /**
   * Logical AND operation
   */
  QkBinaryOpType_LogicAnd = 4,
  /**
   * Logical OR operation
   */
  QkBinaryOpType_LogicOr = 5,
  /**
   * Equality comparison
   */
  QkBinaryOpType_Equal = 6,
  /**
   * Inequality comparison
   */
  QkBinaryOpType_NotEqual = 7,
  /**
   * Less than comparison
   */
  QkBinaryOpType_Less = 8,
  /**
   * Less than or equal comparison
   */
  QkBinaryOpType_LessEqual = 9,
  /**
   * Greater than comparison
   */
  QkBinaryOpType_Greater = 10,
  /**
   * Greater than or equal comparison
   */
  QkBinaryOpType_GreaterEqual = 11,
  /**
   * Left shift operation
   */
  QkBinaryOpType_ShiftLeft = 12,
  /**
   * Right shift operation
   */
  QkBinaryOpType_ShiftRight = 13,
  /**
   * Addition operation
   */
  QkBinaryOpType_Add = 14,
  /**
   * Subtraction operation
   */
  QkBinaryOpType_Sub = 15,
  /**
   * Multiplication operation
   */
  QkBinaryOpType_Mul = 16,
  /**
   * Division operation
   */
  QkBinaryOpType_Div = 17,
};
#ifndef __cplusplus
#if __STDC_VERSION__ >= 202311L
typedef enum QkBinaryOpType QkBinaryOpType;
#else
typedef uint8_t QkBinaryOpType;
#endif // __STDC_VERSION__ >= 202311L
#endif // __cplusplus

/**
 * The data types that can be used in classical expressions.
 */
enum QkExprType
#if defined(__cplusplus) || __STDC_VERSION__ >= 202311L
  : uint8_t
#endif // defined(__cplusplus) || __STDC_VERSION__ >= 202311L
 {
  /**
   * Boolean type
   */
  QkExprType_Bool = 0,
  /**
   * Duration type
   */
  QkExprType_Duration = 1,
  /**
   * Floating-point type
   */
  QkExprType_Float = 2,
  /**
   * Unsigned integer type
   */
  QkExprType_Uint = 3,
};
#ifndef __cplusplus
#if __STDC_VERSION__ >= 202311L
typedef enum QkExprType QkExprType;
#else
typedef uint8_t QkExprType;
#endif // __STDC_VERSION__ >= 202311L
#endif // __cplusplus

/**
 * The operation types a unary expression can hold.
 * Values are one-based to match the Python convention of the classical expression system.
 */
enum QkUnaryOpType
#if defined(__cplusplus) || __STDC_VERSION__ >= 202311L
  : uint8_t
#endif // defined(__cplusplus) || __STDC_VERSION__ >= 202311L
 {
  /**
   * Bitwise NOT operation
   */
  QkUnaryOpType_BitNot = 1,
  /**
   * Logical NOT operation
   */
  QkUnaryOpType_LogicNot = 2,
  /**
   * Arithmetic negation
   */
  QkUnaryOpType_Negate = 3,
};
#ifndef __cplusplus
#if __STDC_VERSION__ >= 202311L
typedef enum QkUnaryOpType QkUnaryOpType;
#else
typedef uint8_t QkUnaryOpType;
#endif // __STDC_VERSION__ >= 202311L
#endif // __cplusplus

/**
 * Represents different time units used in duration expressions.
 */
enum QkDurationType
#if defined(__cplusplus) || __STDC_VERSION__ >= 202311L
  : uint8_t
#endif // defined(__cplusplus) || __STDC_VERSION__ >= 202311L
 {
  /**
   * System time units
   */
  QkDurationType_Dt = 0,
  /**
   * Picoseconds
   */
  QkDurationType_Ps = 1,
  /**
   * Nanoseconds
   */
  QkDurationType_Ns = 2,
  /**
   * Microseconds
   */
  QkDurationType_Us = 3,
  /**
   * Milliseconds
   */
  QkDurationType_Ms = 4,
  /**
   * Seconds
   */
  QkDurationType_S = 5,
};
#ifndef __cplusplus
#if __STDC_VERSION__ >= 202311L
typedef enum QkDurationType QkDurationType;
#else
typedef uint8_t QkDurationType;
#endif // __STDC_VERSION__ >= 202311L
#endif // __cplusplus

/**
 * This enum represents the different kinds of control flow instructions that can appear
 * in a quantum circuit.
 */
enum QkControlFlowKind
#if defined(__cplusplus) || __STDC_VERSION__ >= 202311L
  : uint8_t
#endif // defined(__cplusplus) || __STDC_VERSION__ >= 202311L
 {
  /**
   * A Box instruction
   */
  QkControlFlowKind_Box = 0,
  /**
   * Break loop instruction
   */
  QkControlFlowKind_BreakLoop = 1,
  /**
   * Continue loop instruction
   */
  QkControlFlowKind_ContinueLoop = 2,
  /**
   * For loop instruction
   */
  QkControlFlowKind_ForLoop = 3,
  /**
   * If-else instruction
   */
  QkControlFlowKind_IfElse = 4,
  /**
   * Switch case instruction
   */
  QkControlFlowKind_Switch = 5,
  /**
   * While loop instruction
   */
  QkControlFlowKind_While = 6,
};
#ifndef __cplusplus
#if __STDC_VERSION__ >= 202311L
typedef enum QkControlFlowKind QkControlFlowKind;
#else
typedef uint8_t QkControlFlowKind;
#endif // __STDC_VERSION__ >= 202311L
#endif // __cplusplus

/**
 * Represents the type of condition or Switch target in a control flow instruction.
 *
 * This enum is used to identify whether a condition (in IfElse or While instructions)
 * or a Switch target (in Switch instructions) operates on a classical bit, a classical
 * register, or a classical expression.
 */
enum QkConditionType
#if defined(__cplusplus) || __STDC_VERSION__ >= 202311L
  : uint8_t
#endif // defined(__cplusplus) || __STDC_VERSION__ >= 202311L
 {
  /**
   * Condition based on a classical bit
   */
  QkConditionType_ClBit = 0,
  /**
   * Condition based on a classical register
   */
  QkConditionType_ClReg = 1,
  /**
   * Condition based on a classical expression
   */
  QkConditionType_Expr = 2,
};
#ifndef __cplusplus
#if __STDC_VERSION__ >= 202311L
typedef enum QkConditionType QkConditionType;
#else
typedef uint8_t QkConditionType;
#endif // __STDC_VERSION__ >= 202311L
#endif // __cplusplus

/**
 * Represents the kind of duration specification for a Box instruction.
 *
 * Box instructions can have no duration, a concrete duration value, or a duration
 * specified as a classical expression.
 */
enum QkBoxDurationKind
#if defined(__cplusplus) || __STDC_VERSION__ >= 202311L
  : uint8_t
#endif // defined(__cplusplus) || __STDC_VERSION__ >= 202311L
 {
  /**
   * No duration specified
   */
  QkBoxDurationKind_NoDuration = 0,
  /**
   * Concrete duration value (represented as `QkDurationInfo`)
   */
  QkBoxDurationKind_Duration = 1,
  /**
   * Duration specified as a classical expression
   */
  QkBoxDurationKind_Expr = 2,
};
#ifndef __cplusplus
#if __STDC_VERSION__ >= 202311L
typedef enum QkBoxDurationKind QkBoxDurationKind;
#else
typedef uint8_t QkBoxDurationKind;
#endif // __STDC_VERSION__ >= 202311L
#endif // __cplusplus

/**
 * The type of collection used in a ForLoop control flow instruction.
 */
enum QkLoopCollectionType
#if defined(__cplusplus) || __STDC_VERSION__ >= 202311L
  : uint8_t
#endif // defined(__cplusplus) || __STDC_VERSION__ >= 202311L
 {
  /**
   * The loop iterates over an explicit list of elements
   */
  QkLoopCollectionType_List = 0,
  /**
   * The loop iterates over a Python-style range (start, stop, step)
   */
  QkLoopCollectionType_Range = 1,
};
#ifndef __cplusplus
#if __STDC_VERSION__ >= 202311L
typedef enum QkLoopCollectionType QkLoopCollectionType;
#else
typedef uint8_t QkLoopCollectionType;
#endif // __STDC_VERSION__ >= 202311L
#endif // __cplusplus

/**
 * The kind of loop parameter in a ForLoop control flow instruction.
 *
 * This enum indicates whether a for-loop has no loop parameter, uses a Parameter symbol,
 * or uses a Variable (``QkVar``) to track the iteration value.
 */
enum QkLoopParamKind
#if defined(__cplusplus) || __STDC_VERSION__ >= 202311L
  : uint8_t
#endif // defined(__cplusplus) || __STDC_VERSION__ >= 202311L
 {
  /**
   * No loop parameter is specified for the ForLoop instruction
   */
  QkLoopParamKind_NoLoopParam = 0,
  /**
   * Loop parameter is a Parameter
   */
  QkLoopParamKind_Parameter = 1,
  /**
   * Loop parameter is a Variable
   */
  QkLoopParamKind_Variable = 2,
};
#ifndef __cplusplus
#if __STDC_VERSION__ >= 202311L
typedef enum QkLoopParamKind QkLoopParamKind;
#else
typedef uint8_t QkLoopParamKind;
#endif // __STDC_VERSION__ >= 202311L
#endif // __cplusplus

/**
 * The type of symbol in a ForLoop context.
 *
 * This enum indicates whether a symbol is a standalone variable or an element
 * inside a parameter vector accessed by an index.
 */
enum QkSymbolType
#if defined(__cplusplus) || __STDC_VERSION__ >= 202311L
  : uint8_t
#endif // defined(__cplusplus) || __STDC_VERSION__ >= 202311L
 {
  /**
   * A standalone symbol with a simple name
   */
  QkSymbolType_Standalone = 0,
  /**
   * An element symbol with a base name and index
   */
  QkSymbolType_Element = 1,
};
#ifndef __cplusplus
#if __STDC_VERSION__ >= 202311L
typedef enum QkSymbolType QkSymbolType;
#else
typedef uint8_t QkSymbolType;
#endif // __STDC_VERSION__ >= 202311L
#endif // __cplusplus

/**
 * The type of node in a ``QkDag``.
 *
 * Operation nodes represent an applied instruction. The rest of the nodes are
 * considered "wire" nodes and represent the endpoints of the DAG's data dependency
 * chains.
 */
enum QkDagNodeType
#if defined(__cplusplus) || __STDC_VERSION__ >= 202311L
  : uint8_t
#endif // defined(__cplusplus) || __STDC_VERSION__ >= 202311L
 {
  /**
   * Operation node.
   */
  QkDagNodeType_Operation = 0,
  /**
   * Qubit wire start node.
   */
  QkDagNodeType_QubitIn = 1,
  /**
   * Qubit wire end node.
   */
  QkDagNodeType_QubitOut = 2,
  /**
   * Clbit wire start node.
   */
  QkDagNodeType_ClbitIn = 3,
  /**
   * Clbit wire end node.
   */
  QkDagNodeType_ClbitOut = 4,
  /**
   * Classical variable wire start node.
   */
  QkDagNodeType_VarIn = 5,
  /**
   * Classical variable wire end node.
   */
  QkDagNodeType_VarOut = 6,
};
#ifndef __cplusplus
#if __STDC_VERSION__ >= 202311L
typedef enum QkDagNodeType QkDagNodeType;
#else
typedef uint8_t QkDagNodeType;
#endif // __STDC_VERSION__ >= 202311L
#endif // __cplusplus

/**
 * Named handle to the alphabet of single-qubit terms.
 *
 * This is just the Rust-space representation.  We make a separate Python-space `enum.IntEnum` to
 * represent the same information, since we enforce strongly typed interactions in Rust, including
 * not allowing the stored values to be outside the valid `BitTerm`\ s, but doing so in Python would
 * make it very difficult to use the class efficiently with Numpy array views.  We attach this
 * sister class of `BitTerm` to `SparseObservable` as a scoped class.
 *
 * # Representation
 *
 * The `u8` representation and the exact numerical values of these are part of the public API.  The
 * low two bits are the symplectic Pauli representation of the required measurement basis with Z in
 * the Lsb0 and X in the Lsb1 (e.g. X and its eigenstate projectors all have their two low bits as
 * `0b10`).  The high two bits are `00` for the operator, `10` for the projector to the positive
 * eigenstate, and `01` for the projector to the negative eigenstate.
 *
 * The `0b00_00` representation thus ends up being the natural representation of the `I` operator,
 * but this is never stored, and is not named in the enumeration.
 *
 * This operator does not store phase terms of $-i$.  `BitTerm::Y` has `(1, 1)` as its `(z, x)`
 * representation, and represents exactly the Pauli Y operator; any additional phase is stored only
 * in a corresponding coefficient.
 *
 * # Dev notes
 *
 * This type is required to be `u8`, but it's a subtype of `u8` because not all `u8` are valid
 * `BitTerm`\ s.  For interop with Python space, we accept Numpy arrays of `u8` to represent this,
 * which we transmute into slices of `BitTerm`, after checking that all the values are correct (or
 * skipping the check if Python space promises that it upheld the checks).
 *
 * We deliberately _don't_ impl `numpy::Element` for `BitTerm` (which would let us accept and
 * return `PyArray1<BitTerm>` at Python-space boundaries) so that it's clear when we're doing
 * the transmute, and we have to be explicit about the safety of that.
 */
enum QkBitTerm
#if defined(__cplusplus) || __STDC_VERSION__ >= 202311L
  : uint8_t
#endif // defined(__cplusplus) || __STDC_VERSION__ >= 202311L
 {
  /**
   * Pauli X operator.
   */
  QkBitTerm_X = 2,
  /**
   * Projector to the positive eigenstate of Pauli X.
   */
  QkBitTerm_Plus = 10,
  /**
   * Projector to the negative eigenstate of Pauli X.
   */
  QkBitTerm_Minus = 6,
  /**
   * Pauli Y operator.
   */
  QkBitTerm_Y = 3,
  /**
   * Projector to the positive eigenstate of Pauli Y.
   */
  QkBitTerm_Right = 11,
  /**
   * Projector to the negative eigenstate of Pauli Y.
   */
  QkBitTerm_Left = 7,
  /**
   * Pauli Z operator.
   */
  QkBitTerm_Z = 1,
  /**
   * Projector to the positive eigenstate of Pauli Z.
   */
  QkBitTerm_Zero = 9,
  /**
   * Projector to the negative eigenstate of Pauli Z.
   */
  QkBitTerm_One = 5,
};
#ifndef __cplusplus
#if __STDC_VERSION__ >= 202311L
typedef enum QkBitTerm QkBitTerm;
#else
typedef uint8_t QkBitTerm;
#endif // __STDC_VERSION__ >= 202311L
#endif // __cplusplus

/**
 * Represents a control flow instruction in a ``QkCircuit``.
 *
 * This struct holds information about a control flow instruction and provides
 * access to its properties and nested circuit blocks. It also maintains mappings
 * of qubits and classical bits relative to the top-level circuit, which is
 * necessary for correctly interpreting nested control flow structures.
 *
 * A pointer to this object is only valid as long as the source circuit remains alive.
 * Users must ensure the circuit is not freed while any ``QkControlFlowInstruction``
 * referencing it still exists.
 */
typedef struct QkControlFlowInstruction QkControlFlowInstruction;

/**
 * The core data structure representing a quantum circuit's instruction sequence and metadata.
 *
 * `CircuitData` is the internal Rust representation of a quantum circuit, storing the complete
 * state including instructions, quantum and classical bits, registers, variables, and parameters.
 * This struct is designed for efficient manipulation and traversal of circuit data from Rust code.
 *
 * The data is stored in a packed format for memory efficiency, with interned bit arguments to
 * reduce duplication. Instructions are stored as [`PackedInstruction`] objects in a vector,
 * allowing for fast sequential access and modification.
 *
 * # Fields
 *
 * The struct contains:
 * - Instruction data and interned bit caches
 * - Quantum and classical bit registries
 * - Quantum and classical registers
 * - Control flow blocks for nested circuit structures
 * - Variable and stretch registries for dynamic circuits
 * - Parameter table for parameterized gates
 * - Global phase information
 *
 * # Usage
 *
 * This struct is primarily used internally by the circuit implementation and is wrapped by
 * [`PyCircuitData`] for Python interoperability. Direct manipulation should be done carefully
 * to maintain invariants around bit indices, parameter tracking, and register consistency.
 */
typedef struct QkCircuit QkCircuit;

typedef struct QkClassicalRegister QkClassicalRegister;

/**
 * Quantum circuit as a directed acyclic graph.
 *
 * There are 3 types of nodes in the graph: inputs, outputs, and operations.
 * The nodes are connected by directed edges that correspond to qubits and
 * bits.
 */
typedef struct QkDag QkDag;

/**
 * A classical expression.
 *
 * Variants that themselves contain [Expr]s are boxed. This is done instead
 * of boxing the contained [Expr]s within the specific type to reduce the
 * number of boxes we need (e.g. Binary would otherwise contain two boxed
 * expressions).
 */
typedef struct QkExprNode QkExprNode;

typedef struct QkParam QkParam;

typedef struct QkQuantumRegister QkQuantumRegister;

/**
 * An observable over Pauli bases that stores its data in a qubit-sparse format.
 *
 * See [PySparseObservable] for detailed docs.
 */
typedef struct QkObs QkObs;

typedef struct QkStretch QkStretch;

/**
 * The base class for a Python ``Target`` object. Contains data representing the
 * constraints of a particular backend.
 *
 * The intent of this struct is to contain data that can be representable and
 * accessible through both Rust and Python, so it can be used for rust-based
 * transpiler processes.
 *
 * This structure contains duplicates of every element in the Python counterpart of
 * `gate_map`. Which improves access for Python while sacrificing a small amount of
 * memory.
 */
typedef struct QkTarget QkTarget;

/**
 * Represents the mapping between qargs and ``InstructionProperties``
 */
typedef struct QkTargetEntry QkTargetEntry;

/**
 * The "layout" caused by transpilation
 *
 * In general Qiskit's transpiler is unitary-preserving up to the initial layout
 * and routing permutations. The initial layout permutation is caused by
 * setting and applying the initial layout (the mapping from virtual circuit
 * qubits to physical qubits on the target) and the routing permtuations are
 * caused by swap gate insertion or permutation elision prior to the initial
 * layout. This struct tracks these details and provide an interface to reason
 * about these permutations.
 */
typedef struct QkTranspileLayout QkTranspileLayout;

/**
 * A container collecting individual attributes shared by the transpiler stages.
 *
 * When transpiling correctly, each individual stage writes specific attributes
 * to this container that will be needed by other stages in sequence. If the container
 * is not initialized, each stage will initialize a new object when necessary.
 */
typedef struct QkTranspilerStageState QkTranspilerStageState;

/**
 * A set of configurations for the VF2 layout passes.
 *
 * See the setter methods associated with this `struct` for the available configurations.
 */
typedef struct QkVF2LayoutConfiguration QkVF2LayoutConfiguration;

/**
 * The result from ``qk_transpiler_pass_standalone_vf2_layout_average()`` and
 * ``qk_transpile_pass_standalone_vf2_layout_exact()``.
 */
typedef struct QkVF2LayoutResult QkVF2LayoutResult;

/**
 * A single scalar value expression.
 */
typedef struct QkValue QkValue;

typedef struct QkVar QkVar;

/**
 * An individual operation count represented by the operation name
 * and the number of instances in the circuit.
 */
typedef struct {
  /**
   * A nul terminated string representing the operation name
   */
  const char *name;
  /**
   * The number of instances of this operation in the circuit
   */
  size_t count;
} QkOpCount;

/**
 * An array of ``OpCount`` objects representing the total counts of all
 * the operation types in a circuit.
 */
typedef struct {
  /**
   * A array of size ``len`` containing ``OpCount`` objects for each
   * type of operation in the circuit
   */
  QkOpCount *data;
  /**
   * The number of elements in ``data``
   */
  size_t len;
} QkOpCounts;

/**
 * A circuit instruction representation.
 *
 * This struct represents the data contained in an individual instruction in a ``QkCircuit``.
 * It is not a pointer to the underlying object, but contains a copy of the properties of the
 * instruction for inspection.
 */
typedef struct {
  /**
   * The instruction name
   */
  char *name;
  /**
   * A pointer to an array of qubit indices this instruction operates on.
   */
  uint32_t *qubits;
  /**
   * A pointer to an array of clbit indices this instruction operates on.
   */
  uint32_t *clbits;
  /**
   * A pointer to an array of parameter values for this instruction.
   */
  QkParam **params;
  /**
   * The number of qubits for this instruction.
   */
  uint32_t num_qubits;
  /**
   * The number of clbits for this instruction.
   */
  uint32_t num_clbits;
  /**
   * The number of parameters for this instruction.
   */
  uint32_t num_params;
} QkCircuitInstruction;

/**
 * A representation of Pauli product rotation data.
 *
 * A Pauli product rotation implements a rotation of an ``angle`` about an axis defined
 * by a Pauli product on ``len`` qubits. The Pauli here is represented in ZX format with
 * two Boolean arrays representing the Z and X components.
 */
typedef struct {
  /**
   * Pointer to an length-`len` array of Z components.
   */
  bool *z;
  /**
   * Pointer to an length-`len` array of X components.
   */
  bool *x;
  /**
   * The number of Pauli terms.
   */
  size_t len;
  /**
   * The rotation angle.
   */
  QkParam *angle;
} QkPauliProductRotation;

/**
 * A representation of Pauli product measurement data.
 *
 * A Pauli product measurement implements a projection onto the eigenspace of the defined
 * Pauli product on ``len`` qubits. The Pauli here is represented in ZX format with
 * two Boolean arrays representing the Z and X components and can include a minus sign, indicated
 * by ``flip_outcome``.
 */
typedef struct {
  /**
   * Pointer to an length-`len` array of Z components.
   */
  bool *z;
  /**
   * Pointer to an length-`len` array of X components.
   */
  bool *x;
  /**
   * The number of Pauli terms.
   */
  size_t len;
  /**
   * Whether the measurement outcome has a minus sign.
   */
  bool flip_outcome;
} QkPauliProductMeasurement;

/**
 * The configuration options for the ``qk_circuit_draw`` function.
 */
typedef struct {
  /**
   * If `true`, bundles classical registers into single wires.
   */
  bool bundle_cregs;
  /**
   * If `true`, merges the bottom and top lines of adjacent wires.
   */
  bool merge_wires;
  /**
   * Sets the line length for wrapping the rendered text. Use 0
   * to auto-detect console width. Use `SIZE_MAX` to effectively skip
   * wrapping altogether.
   */
  size_t fold;
} QkCircuitDrawerConfig;

/**
 * The complete representation of the data type used for an expression.
 */
typedef struct {
  /**
   * The expression type
   */
  QkExprType ty;
  /**
   * Bit width for the Uint expression type
   */
  uint32_t width;
} QkExprTypeInfo;

/**
 * Describes a binary expression, including its operator, operands, result type and whether it is constant.
 * Returned by the `qk_expr_binary_info` function. The `left` and `right` fields are borrowed pointers to
 * the operands of the binary operation expression.
 */
typedef struct {
  /**
   * The binary operator
   */
  QkBinaryOpType op;
  /**
   * Borrowed pointer to the left operand expression
   */
  const QkExprNode *left;
  /**
   * Borrowed pointer to the right operand expression
   */
  const QkExprNode *right;
  /**
   * Result type of the operation
   */
  QkExprTypeInfo ty;
  /**
   * Whether the expression is constant
   */
  bool constant;
} QkBinaryExprInfo;

/**
 * Describes a unary expression, including its operator, operand, result type and whether it is constant.
 * Returned by the `qk_expr_unary_info` function. The `operand` field is a borrowed pointer to the operand
 * of the unary operation expression.
 */
typedef struct {
  /**
   * The unary operator
   */
  QkUnaryOpType op;
  /**
   * Borrowed pointer to the operand expression
   */
  const QkExprNode *operand;
  /**
   * Result type of the operation
   */
  QkExprTypeInfo ty;
  /**
   * Whether the expression is constant
   */
  bool constant;
} QkUnaryExprInfo;

/**
 * Describes a cast expression, including the operand, target type, whether it is implicit, and whether it is constant.
 * Returned by the `qk_expr_cast_info` function. The `operand` field is a borrowed pointer to the operand
 * of the cast expression.
 */
typedef struct {
  /**
   * Borrowed pointer to the operand expression being cast
   */
  const QkExprNode *operand;
  /**
   * Target type of the cast
   */
  QkExprTypeInfo ty;
  /**
   * Whether the cast is implicit (automatic) or explicit
   */
  bool implicit;
  /**
   * Whether the expression is constant
   */
  bool constant;
} QkCastExprInfo;

/**
 * Describes an index expression, including the target, index, result type and whether it is constant.
 * Returned by the `qk_expr_index_info` function. The `target` and `index` fields are borrowed pointers
 * to the target and index of the index operation expression.
 */
typedef struct {
  /**
   * Borrowed pointer to the target expression being indexed
   */
  const QkExprNode *target;
  /**
   * Borrowed pointer to the index expression
   */
  const QkExprNode *index;
  /**
   * Result type of the indexing operation
   */
  QkExprTypeInfo ty;
  /**
   * Whether the expression is constant
   */
  bool constant;
} QkIndexExprInfo;

/**
 * A union to hold either system time units (dt) as an integer or real time as a float.
 *
 * This union is part of the `QkDurationInfo` struct and should not be used directly.
 */
typedef union {
  /**
   * System time units (active when `ty` in `QkDurationInfo` is `QkDurationType_Dt`)
   */
  int64_t dt;
  /**
   * Real time value (active for all other duration types)
   */
  double time;
} QkDurationValue;

/**
 * The complete representation of a duration value.
 *
 * The `ty` field acts as a discriminant that determines which field of the `value` union is active.
 *
 * When initialized from C, it is the user's responsibility to ensure that:
 * - When `ty` is `QkDurationType_Dt`, the duration is stored as an integer in `value.dt`.
 * - For all other duration types the duration is stored as a floating-point value in `value.time`.
 *
 */
typedef struct {
  /**
   * The duration unit type (discriminant for the union)
   */
  QkDurationType ty;
  /**
   * The duration value
   */
  QkDurationValue value;
} QkDurationInfo;

/**
 * Information about a classical bit condition.
 *
 * This struct contains the details of a condition that operates on a single classical bit
 */
typedef struct {
  /**
   * The index of the classical bit in the circuit
   */
  uint32_t clbit;
  /**
   * The expected value of the classical bit (true or false)
   */
  bool condition;
} QkConditionBitInfo;

/**
 * A struct containing loop elements from a ForLoop control flow instruction.
 *
 * This struct is returned by `qk_control_flow_loop_elements` and contains both
 * a pointer to the array of loop elements and the number of elements in the array.
 * The pointer is borrowed and must not be freed by the caller.
 */
typedef struct {
  /**
   * Pointer to the array of loop elements.
   */
  const ptrdiff_t *elements;
  /**
   * Number of elements in the array.
   */
  size_t len;
} QkLoopElements;

/**
 * Symbol information including type and data.
 *
 * This struct represents a symbol in a ForLoop context, which can be
 * either a standalone variable or an indexed element.
 */
typedef struct {
  /**
   * The type of symbol (standalone or element)
   */
  QkSymbolType ty;
  /**
   * A null-terminated C string containing the symbol name. For standalone symbols,
   * this is the variable name. For element symbols, this is the base name of the parameter
   * vector. The caller is responsible for freeing this string using `qk_str_free`.
   */
  char *name;
  /**
   * For element symbols, this is the index into the parameter vector. For standalone
   * symbols, this field is unused and should be ignored.
   */
  size_t index;
} QkSymbolInfo;

/**
 * Contains the labels for a Switch case.
 *
 * This struct holds an array of label values that a Switch case matches against.
 * For example, a case like ``case(1, 2, 3)`` would have three labels: 1, 2, and 3.
 * The memory for the labels array is allocated by `qk_control_flow_switch_case_labels_uint`
 * and must be freed using `qk_control_flow_switch_case_labels_clear`.
 */
typedef struct {
  /**
   * Pointer to an array of label values
   */
  const uint64_t *labels;
  /**
   * Number of labels in the array
   */
  size_t num_labels;
} QkSwitchCaseLabels;

/**
 * A struct for storing successors and predecessors information
 * retrieved from `qk_dag_successors` and `qk_dag_predecessors`, respectively.
 *
 * This object is read-only from C. To satisfy the safety guarantees of `qk_dag_neighbors_clear`,
 * you must not overwrite any data initialized by `qk_dag_successors` or `qk_dag_predecessors`,
 * including any pointed-to data.
 */
typedef struct {
  /**
   * Array of size `num_neighbors` of node indices.
   */
  const uint32_t *neighbors;
  /**
   * The length of the `neighbors` array.
   */
  size_t num_neighbors;
} QkDagNeighbors;

/**
 * A term in a ``QkObs``.
 *
 * This contains the coefficient (``coeff``), the number of qubits of the observable
 * (``num_qubits``) and pointers to the ``bit_terms`` and ``indices`` arrays, which have
 * length ``len``. It's the responsibility of the user that the data is coherent,
 * see also the below section on safety.
 *
 * # Safety
 *
 * * ``bit_terms`` must be a non-null, aligned pointer to ``len`` elements of type ``QkBitTerm``.
 * * ``indices`` must be a non-null, aligned pointer to ``len`` elements of type ``uint32_t``.
 */
typedef struct {
  /**
   * The coefficient of the observable term.
   */
  QkComplex64 coeff;
  /**
   * Length of the ``bit_terms`` and ``indices`` arrays.
   */
  size_t len;
  /**
   * An aligned pointer to ``len`` elements of type ``QkBitTerm``.  This can be ``NULL`` if and
   * only if ``len`` is 0.
   */
  QkBitTerm *bit_terms;
  /**
   * An aligned pointer to ``len`` elements of type ``uint32_t``.  This can be ``NULL`` if and
   * only if ``len`` is 0.
   */
  uint32_t *indices;
  /**
   * The number of qubits the observable term is defined on.
   */
  uint32_t num_qubits;
} QkObsTerm;

/**
 * An adjacency-list representation of a coupling graph.
 *
 * This is initialized by `qk_neighbors_from_target`.
 *
 * This object is read-only from C.  To satisfy the safety guarantees of `qk_neighbors_clear`, you
 * must not overwrite any data initialized by `qk_neighbors_from_target`, including any pointed-to
 * data.
 *
 * # Representation
 *
 * After initialization by `qk_neighbors_from_target`, the structure will be in one of two modes:
 *
 * * all-to-all connectivity
 * * limited two-qubit connectivity
 *
 * In the all-to-all case, the `neighbors` and `partition` pointers will both be the null pointer,
 * and `num_qubits` will be the number of qubits in the `QkTarget`.  These objects do not have
 * backing allocations, and do not need to be given to `qk_neighbors_clear` (though this function
 * is a safe no-op in this case).
 *
 * In the limited two-qubit case (which is by far the more common for real hardware), see the
 * documentation of the structure members for their interpretation.
 */
typedef struct {
  /**
   * A partitioned adjacency-list representation of the neighbors of each qubit.  This pointer is
   * valid for exactly `partition[num_qubits + 1]` reads.
   *
   * For qubit number `i`, its neighbors are the values between offsets `partition[i]`
   * (inclusive) and `partition[i + 1]` (exclusive).  The values between these two offsets are
   * sorted in ascending order and contain no duplicates.
   */
  const uint32_t *neighbors;
  /**
   * How the `neighbors` field is partitioned into slices.  This pointer is valid for exactly
   * `num_qubits + 1` reads.  The first value is always 0, and values increase monotonically.
   */
  const size_t *partition;
  /**
   * The number of qubits.
   */
  uint32_t num_qubits;
} QkNeighbors;

/**
 * The options for running ``qk_transpiler_pass_standalone_sabre_layout``. This struct is used
 * as an input to control the behavior of the layout and routing algorithms.
 */
typedef struct {
  /**
   * The number of forward-backward iterations in the sabre routing algorithm
   */
  size_t max_iterations;
  /**
   * The number of trials to run of the sabre routing algorithm for each iteration. When > 1 the
   * trial that routing trial that results in the output with the fewest swap gates will be
   * selected.
   */
  size_t num_swap_trials;
  /**
   * The number of random layout trials to run. The trial that results in the output with the
   * fewest swap gates will be selected.
   */
  size_t num_random_trials;
  /**
   * A seed value for the pRNG used internally.
   */
  uint64_t seed;
} QkSabreLayoutOptions;

/**
 * A representation of a Target operation's instruction properties.
 */
typedef struct {
  /**
   * The duration, in seconds, of the instruction on the specified set of qubits.
   * Will be set to ``NaN`` if the property is not defined.
   */
  double duration;
  /**
   * The average error rate for the instruction on the specified set of qubits.
   * Will be set to ``NaN`` if the property is not defined.
   */
  double error;
} QkInstructionProperties;

/**
 * Representation of an operation identified within the Target.
 *
 * This struct is created natively by the underlying `Target` API
 * and users should not write to it directly nor try to free its
 * attributes manually as it would lead to undefined behavior. To
 * free this struct, users should call ``qk_target_op_clear`` instead.
 */
typedef struct {
  /**
   * The identifier for the current operation.
   */
  QkOperationKind op_type;
  /**
   * The name of the operation.
   */
  char *name;
  /**
   * The number of qubits this operation supports. Will default to
   * `(uint32_t)-1` in the case of a variadic.
   */
  uint32_t num_qubits;
  /**
   * The parameters tied to this operation, as `QkParam`.
   * If there are no parameters then this value will be represented
   * with a `NULL` pointer.
   */
  const QkParam **params;
  /**
   * The number of parameters supported by this operation. Will default to
   * `(uint32_t)-1` in the case of a variadic.
   */
  uint32_t num_params;
} QkTargetOp;

/**
 * The options for running the transpiler
 */
typedef struct {
  /**
   * The optimization level to run the transpiler with. Valid values are 0, 1, 2, or 3.
   */
  uint8_t optimization_level;
  /**
   * The seed for the transpiler. If set to a negative number this means no seed will be
   * set and the RNGs used in the transpiler will be seeded from system entropy.
   */
  int64_t seed;
  /**
   * The approximation degree a heuristic dial where 1.0 means no approximation (up to numerical
   * tolerance) and 0.0 means the maximum approximation. A `NAN` value indicates that
   * approximation is allowed up to the reported error rate for an operation in the target.
   */
  double approximation_degree;
} QkTranspileOptions;

/**
 * The container result object from ``qk_transpile``
 *
 * When the transpiler successfully compiles a quantum circuit for a given target it
 * returns the transpiled circuit and the layout. The ``qk_transpile`` function will
 * write pointers to the fields in this struct when it successfully executes, you can
 * initialize this struct with null pointers or leave them unset as the values are never
 * read by ``qk_transpile`` and only written to. After calling ``qk_transpile`` you are
 * responsible for calling ``qk_circuit_free`` and ``qk_transpile_layout_free`` on the
 * members of this struct.
 */
typedef struct {
  /**
   * The compiled circuit.
   */
  QkCircuit *circuit;
  /**
   * Metadata about the initial and final virtual-to-physical layouts.
   */
  QkTranspileLayout *layout;
} QkTranspileResult;
